package app;


import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.lang.*;
import java.lang.reflect.*;
import java.util.StringTokenizer;
import java.io.*;

import java.util.function.Predicate;
import java.util.function.Function;

class FromPython
  implements SystemTypes
{

  public FromPython()
  {

  }

  public Object clone()
  { FromPython result = new FromPython();
    return result;
  }



  public String toString()
  { String _res_ = "(FromPython) ";
    return _res_;
  }

    public void initialise()
  {     FromPython frompythonx = this;
      
      
      
      
      
      
      
      
      








  }


    public ArrayList comp(String date_str)
  { ArrayList result;
    FromPython frompythonx = this;
      return Ocl.split(date_str,"/");
  }


    public int year(Object date_str)
  { int result;
    FromPython frompythonx = this;
      return Ocl.toInteger(( "" + Ocl.last(frompythonx.comp(date_str + "")) ));
  }


    public int month(Object date_str)
  { int result;
    FromPython frompythonx = this;
      return Ocl.toInteger(( "" + Ocl.last(Ocl.front(frompythonx.comp(date_str + ""))) ));
  }


    public int day(Object date_str)
  { int result;
    FromPython frompythonx = this;
      return Ocl.toInteger(( "" + ((Object) ((ArrayList) Ocl.reverse(frompythonx.comp(date_str + ""))).get(-(-3) - 1)) ));
  }


    public boolean is_leap_year(long year)
  { boolean result;
    FromPython frompythonx = this;
  if (( year % 4 == 0 && year % 100 != 0 ) || ( year % 400 == 0 ))
{     return true;
 }
else {      }

      return false;

  }


    public int calculate_days_between_dates(Object start_date_str,Object end_date_str)
  { int result;
    FromPython frompythonx = this;
    int start_day = frompythonx.day(start_date_str);

    int start_month = frompythonx.month(start_date_str);

    int start_year = frompythonx.year(start_date_str);

    int end_day = frompythonx.day(end_date_str);

    int end_month = frompythonx.month(end_date_str);

    int end_year = frompythonx.year(end_date_str);

    int days = 0;

    while ((start_year - (end_year)) < 0 || ( start_year == end_year && (start_month - (end_month)) < 0 )) 
  {   int days_in_month = 30;

  if (start_month == 2)
{ if (frompythonx.is_leap_year(start_year))
{   days_in_month = 29;
 }
else {   days_in_month = 28;
 }

 }
else { if (( Ocl.concatenate(Ocl.addSequence((new ArrayList<Integer>()), new Integer(4)), Ocl.concatenate(Ocl.addSequence((new ArrayList<Integer>()), new Integer(6)), Ocl.concatenate(Ocl.addSequence((new ArrayList<Integer>()), new Integer(9)), Ocl.addSequence((new ArrayList<Integer>()), new Integer(11))))) ).contains(start_month))
{   days_in_month = 30;
 }
else {   days_in_month = 31;
 }

 }

    days = days + days_in_month - start_day + 1;
    start_day = 1;
    start_month = start_month + 1;
  if (start_month > 12)
{   start_month = 1;
    start_year = start_year + 1;

 }
else {      }






 }
    days = days + end_day - start_day;
      return days;









  }


    public int days360(Object I,Object S,Object dc,Object M)
  { int result;
    FromPython frompythonx = this;
      return frompythonx.calculate_days_between_dates(I,S);
  }


    public ArrayList straddle(Object I,Object S,Object p)
  { ArrayList result;
    FromPython frompythonx = this;
      return Ocl.concatenate(Ocl.addSequence((new ArrayList<Object>()), I), Ocl.addSequence((new ArrayList<Object>()), S));
  }


    public double acc(Object I,Object S,double f,double c,String dc,Object M)
  { double result;
    FromPython frompythonx = this;
    int p = Ocl.toInteger(( "" + ( 12 / f ) ));
    ArrayList st = frompythonx.straddle(I,S,p);
   double aif; 
   String ys; 
   String ye; 

  if (( ((String) dc).equals("Actual/365F") ))
{  aif = ( frompythonx.calculate_days_between_dates(((Object) Ocl.first(st)),S) / 365 ) * c;

 }
else { if (( ((String) dc).equals("Actual/ActualISDA") ))
{ if (( frompythonx.is_leap_year(frompythonx.year(((Object) Ocl.first(st)))) && frompythonx.is_leap_year(frompythonx.year(S)) ))
{   aif = ( frompythonx.calculate_days_between_dates(((Object) Ocl.first(st)),S) / 366 ) * c;
 }
else { if (!(frompythonx.is_leap_year(frompythonx.year(((Object) Ocl.first(st)))) && !(frompythonx.is_leap_year(frompythonx.year(S)))))
{   aif = ( frompythonx.calculate_days_between_dates(((Object) Ocl.first(st)),S) / 365 ) * c;
 }
else { if (( frompythonx.is_leap_year(frompythonx.year(((Object) Ocl.first(st)))) && !(frompythonx.is_leap_year(frompythonx.year(S))) ))
{    ys = ( "" + frompythonx.year(((Object) Ocl.first(st))) );

     ye = ( "" + frompythonx.year(S) );

    aif = ( frompythonx.calculate_days_between_dates(((Object) Ocl.first(st)),"31" + "/" + "12" + "/" + ys) / 366 ) * c + ( frompythonx.calculate_days_between_dates("01" + "/" + "01" + "/" + ye,S) / 365 ) * c;


 }
else {   ys = "" + (( "" + frompythonx.year(((Object) Ocl.first(st))) ));
    ye = "" + (( "" + frompythonx.year(S) ));
    aif = ( frompythonx.calculate_days_between_dates(((Object) Ocl.first(st)),"31" + "/" + "12" + "/" + ys) / 365 ) * c + ( frompythonx.calculate_days_between_dates("01" + "/" + "01" + "/" + ye,S) / 366 ) * c;


 }

 }

 }

 }
else { if (( ((String) dc).equals("Actual/364") ))
{   aif = ( frompythonx.calculate_days_between_dates(((Object) Ocl.first(st)),S) / 364 ) * c;
 }
else { if (( ((String) dc).equals("Actual/360") ))
{   aif = ( frompythonx.calculate_days_between_dates(((Object) Ocl.first(st)),S) / 360 ) * c;
 }
else { if (( ((String) dc).equals("Actual/ActualICMA") ))
{   aif = ( frompythonx.calculate_days_between_dates(((Object) Ocl.first(st)),S) / ( f * frompythonx.calculate_days_between_dates(((Object) Ocl.first(st)),st.get(1 + 1 - 1)) ) ) * c;
 }
else {   aif = ( frompythonx.days360(((Object) Ocl.first(st)),S,dc,M) / 360 ) * c;
 }

 }

 }

 }

 }

      return aif;



  }



}



public class Controller implements SystemTypes
{
  ArrayList<FromPython> frompythons = new ArrayList<FromPython>();
  private static Controller uniqueInstance; 


  private Controller() { } 


  public static Controller inst() 
    { if (uniqueInstance == null) 
    { uniqueInstance = new Controller(); }
    return uniqueInstance; } 


  public static void loadModel(String file)
  {
    try
    { BufferedReader br = null;
      File f = new File(file);
      try 
      { br = new BufferedReader(new FileReader(f)); }
      catch (Exception ex) 
      { System.err.println("No file: " + file); return; }
      Class cont = Class.forName("app.Controller");
      java.util.Map objectmap = new java.util.HashMap();
      while (true)
      { String line1;
        try { line1 = br.readLine(); }
        catch (Exception e)
        { return; }
        if (line1 == null)
        { return; }
        line1 = line1.trim();

        if (line1.length() == 0) { continue; }
        if (line1.startsWith("//")) { continue; }
        String left;
        String op;
        String right;
        if (line1.charAt(line1.length() - 1) == '"')
        { int eqind = line1.indexOf("="); 
          if (eqind == -1) { continue; }
          else 
          { left = line1.substring(0,eqind-1).trim();
            op = "="; 
            right = line1.substring(eqind+1,line1.length()).trim();
          }
        }
        else
        { StringTokenizer st1 = new StringTokenizer(line1);
          Vector vals1 = new Vector();
          while (st1.hasMoreTokens())
          { String val1 = st1.nextToken();
            vals1.add(val1);
          }
          if (vals1.size() < 3)
          { continue; }
          left = (String) vals1.get(0);
          op = (String) vals1.get(1);
          right = (String) vals1.get(2);
        }
        if (":".equals(op))
        { int i2 = right.indexOf(".");
          if (i2 == -1)
          { Class cl;
            try { cl = Class.forName("app." + right); }
            catch (Exception _x) { System.err.println("No entity: " + right); continue; }
            Object xinst = cl.newInstance();
            objectmap.put(left,xinst);
            Class[] cargs = new Class[] { cl };
            Method addC = null;
            try { addC = cont.getMethod("add" + right,cargs); }
            catch (Exception _xx) { System.err.println("No entity: " + right); continue; }
            if (addC == null) { continue; }
            Object[] args = new Object[] { xinst };
            addC.invoke(Controller.inst(),args);
          }
          else
          { String obj = right.substring(0,i2);
            String role = right.substring(i2+1,right.length());
            Object objinst = objectmap.get(obj); 
            if (objinst == null) 
            { System.err.println("Warning: no object " + obj); continue; }
            Object val = objectmap.get(left);
            if (val == null &&
                left.length() > 1 &&
                left.startsWith("\"") &&
                left.endsWith("\""))
            { val = left.substring(1,left.length()-1); }
            else if (val == null) 
            { continue; }
            Class objC = objinst.getClass();
            Class typeclass = val.getClass(); 
            Object[] args = new Object[] { val }; 
            Class[] settypes = new Class[] { typeclass };
            Method addrole = Controller.findMethod(objC,"add" + role);
            if (addrole != null) 
            { addrole.invoke(objinst, args); }
            else { System.err.println("Error: cannot add to " + role); }
          }
        }
        else if ("=".equals(op))
        { int i1 = left.indexOf(".");
          if (i1 == -1) 
          { continue; }
          String obj = left.substring(0,i1);
          String att = left.substring(i1+1,left.length());
          Object objinst = objectmap.get(obj); 
          if (objinst == null) 
          { System.err.println("No object: " + obj); continue; }
          Class objC = objinst.getClass();
          Class typeclass; 
          Object val; 
          if (right.charAt(0) == '"' &&
              right.charAt(right.length() - 1) == '"')
          { typeclass = String.class;
            val = right.substring(1,right.length() - 1);
          } 
          else if ("true".equals(right) || "false".equals(right))
          { typeclass = boolean.class;
            if ("true".equals(right))
            { val = new Boolean(true); }
            else
            { val = new Boolean(false); }
          }
          else 
          { val = objectmap.get(right);
            if (val != null)
            { typeclass = val.getClass(); }
            else 
            { int i;
              long l; 
              double d;
              try 
              { i = Integer.parseInt(right);
                typeclass = int.class;
                val = new Integer(i); 
              }
              catch (Exception ee)
              { try 
                { l = Long.parseLong(right);
                  typeclass = long.class;
                  val = new Long(l); 
                }
                catch (Exception eee)
                { try
                  { d = Double.parseDouble(right);
                    typeclass = double.class;
                    val = new Double(d);
                  }
                  catch (Exception ff)
                  { continue; }
                }
              }
            }
          }
          Object[] args = new Object[] { val }; 
          Class[] settypes = new Class[] { typeclass };
          Method setatt = Controller.findMethod(objC,"set" + att);
          if (setatt != null) 
          { setatt.invoke(objinst, args); }
          else { System.err.println("No attribute: " + objC.getName() + "::" + att); }
        }
      }
    } catch (Exception e) { }
  }

  public static Method findMethod(Class c, String name)
  { Method[] mets = c.getMethods(); 
    for (int i = 0; i < mets.length; i++)
    { Method m = mets[i];
      if (m.getName().equals(name))
      { return m; }
    } 
    return null;
  }


  public void checkCompleteness()
  {   }


  public void saveModel(String file)
  { File outfile = new File(file); 
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
    saveModel2(out);
  }

  public void saveModel2(PrintWriter out)
  {
    out.close(); 
  }



  public void addFromPython(FromPython oo) { frompythons.add(oo); }



  public void createAllFromPython(ArrayList<FromPython> frompythonx)
  { for (int i = 0; i < frompythonx.size(); i++)
    { FromPython frompythonx_x = new FromPython();
      frompythonx.set(i,frompythonx_x);
      addFromPython(frompythonx_x);
    }
  }


  public FromPython createFromPython()
  { FromPython frompythonx;
    
    frompythonx = new FromPython();
    addFromPython(frompythonx);

    return frompythonx;
  }



  public void initialise(FromPython frompythonx)
  {   frompythonx.initialise();
   }

  public  ArrayList AllFromPythoninitialise(Collection<FromPython> frompythonxs)
  { 
    ArrayList result = new ArrayList();
    for (Object _i : frompythonxs)
    { FromPython frompythonx = (FromPython) _i;
      initialise(frompythonx);
    }
    return result; 
  }

  public  ArrayList<ArrayList<String>> AllFromPythoncomp(Collection<FromPython> frompythonxs,String date_str)
  { 
    ArrayList<ArrayList<String>> result = new ArrayList<ArrayList<String>>();
    for (Object _i : frompythonxs)
    { FromPython frompythonx = (FromPython) _i;
      result.add(frompythonx.comp(date_str));
    }
    return result; 
  }

  public  ArrayList<Integer> AllFromPythonyear(Collection<FromPython> frompythonxs,Object date_str)
  { 
    ArrayList<Integer> result = new ArrayList<Integer>();
    for (Object _i : frompythonxs)
    { FromPython frompythonx = (FromPython) _i;
      result.add(new Integer(frompythonx.year(date_str)));
    }
    return result; 
  }

  public  ArrayList<Integer> AllFromPythonmonth(Collection<FromPython> frompythonxs,Object date_str)
  { 
    ArrayList<Integer> result = new ArrayList<Integer>();
    for (Object _i : frompythonxs)
    { FromPython frompythonx = (FromPython) _i;
      result.add(new Integer(frompythonx.month(date_str)));
    }
    return result; 
  }

  public  ArrayList<Integer> AllFromPythonday(Collection<FromPython> frompythonxs,Object date_str)
  { 
    ArrayList<Integer> result = new ArrayList<Integer>();
    for (Object _i : frompythonxs)
    { FromPython frompythonx = (FromPython) _i;
      result.add(new Integer(frompythonx.day(date_str)));
    }
    return result; 
  }

  public  ArrayList<Boolean> AllFromPythonis_leap_year(Collection<FromPython> frompythonxs,long year)
  { 
    ArrayList<Boolean> result = new ArrayList<Boolean>();
    for (Object _i : frompythonxs)
    { FromPython frompythonx = (FromPython) _i;
      result.add(new Boolean(frompythonx.is_leap_year(year)));
    }
    return result; 
  }

  public  ArrayList<Integer> AllFromPythoncalculate_days_between_dates(Collection<FromPython> frompythonxs,Object start_date_str,Object end_date_str)
  { 
    ArrayList<Integer> result = new ArrayList<Integer>();
    for (Object _i : frompythonxs)
    { FromPython frompythonx = (FromPython) _i;
      result.add(new Integer(frompythonx.calculate_days_between_dates(start_date_str, end_date_str)));
    }
    return result; 
  }

  public  ArrayList<Integer> AllFromPythondays360(Collection<FromPython> frompythonxs,Object I,Object S,Object dc,Object M)
  { 
    ArrayList<Integer> result = new ArrayList<Integer>();
    for (Object _i : frompythonxs)
    { FromPython frompythonx = (FromPython) _i;
      result.add(new Integer(frompythonx.days360(I, S, dc, M)));
    }
    return result; 
  }

  public  ArrayList<ArrayList<Object>> AllFromPythonstraddle(Collection<FromPython> frompythonxs,Object I,Object S,Object p)
  { 
    ArrayList<ArrayList<Object>> result = new ArrayList<ArrayList<Object>>();
    for (Object _i : frompythonxs)
    { FromPython frompythonx = (FromPython) _i;
      result.add(frompythonx.straddle(I, S, p));
    }
    return result; 
  }

  public  ArrayList<Double> AllFromPythonacc(Collection<FromPython> frompythonxs,Object I,Object S,double f,double c,String dc,Object M)
  { 
    ArrayList<Double> result = new ArrayList<Double>();
    for (Object _i : frompythonxs)
    { FromPython frompythonx = (FromPython) _i;
      result.add(new Double(frompythonx.acc(I, S, f, c, dc, M)));
    }
    return result; 
  }



  public void killAllFromPython(Collection<FromPython> frompythonxx)
  { for (Object _o : frompythonxx)
    { killFromPython((FromPython) _o); }
  }

  public void killFromPython(FromPython frompythonxx)
  { frompythons.remove(frompythonxx);
  }



  public static void main(String[] args)
  { FromPython fp = new FromPython(); 
  
    java.util.Date d1 = new java.util.Date(); 
	long t1 = d1.getTime(); 

    int startyr = 1800; // 2000, 1800, 1800
	int endyr = 4024; // 2024, 2024, 4024
    for (int yr = startyr; yr < endyr; yr ++) 
	{ for (int mnt = 10; mnt < 13; mnt++) 
      { for (int dd = 10; dd < 31; dd++) 
        { fp. acc("01/" + mnt + "/" + (yr-1), 
                  dd + "/" + mnt + "/" + yr, 
                  2 , 0.02, "Actual/ActualISDA", "31/07/2024"); 
		} 
	  }
    }  
	
	java.util.Date d2 = new java.util.Date(); 
	long t2 = d2.getTime(); 
    System.out.println((t2 - t1)); 
  }


   
}


