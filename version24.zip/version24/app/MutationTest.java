package app;

import java.util.Vector;
import java.util.List;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class MutationTest
{
  public static void comp_mutation_tests(FromPython _self, int[] _counts, int[] _totals)
  {   try {
        String date_str = "";

    ArrayList<String> comp_result = _self.comp(date_str);
    System.out.println("Test 0 of comp on " + _self + " result = " + comp_result);

  } catch (Throwable _e) { _e.printStackTrace(); }

  try {
        String date_str = " abc_XZ ";

    ArrayList<String> comp_result = _self.comp(date_str);
    System.out.println("Test 1 of comp on " + _self + " result = " + comp_result);

  } catch (Throwable _e) { _e.printStackTrace(); }

  try {
        String date_str = "#�$* &~@':";

    ArrayList<String> comp_result = _self.comp(date_str);
    System.out.println("Test 2 of comp on " + _self + " result = " + comp_result);

  } catch (Throwable _e) { _e.printStackTrace(); }


   for (int i = 0; i < _counts.length; i++)
   { if (_totals[i] > 0)
     { System.out.println("Test " + i + " detects " + (100.0*_counts[i])/_totals[i] + "% comp mutants"); }
     }
   }



  public static void year_mutation_tests(FromPython _self, int[] _counts, int[] _totals)
  { 
   for (int i = 0; i < _counts.length; i++)
   { if (_totals[i] > 0)
     { System.out.println("Test " + i + " detects " + (100.0*_counts[i])/_totals[i] + "% year mutants"); }
     }
   }



  public static void month_mutation_tests(FromPython _self, int[] _counts, int[] _totals)
  { 
   for (int i = 0; i < _counts.length; i++)
   { if (_totals[i] > 0)
     { System.out.println("Test " + i + " detects " + (100.0*_counts[i])/_totals[i] + "% month mutants"); }
     }
   }



  public static void day_mutation_tests(FromPython _self, int[] _counts, int[] _totals)
  { 
   for (int i = 0; i < _counts.length; i++)
   { if (_totals[i] > 0)
     { System.out.println("Test " + i + " detects " + (100.0*_counts[i])/_totals[i] + "% day mutants"); }
     }
   }



  public static void is_leap_year_mutation_tests(FromPython _self, int[] _counts, int[] _totals)
  {   try {
        long year = 0;

    boolean is_leap_year_result = _self.is_leap_year(year);
    System.out.println("Test 0 of is_leap_year on " + _self + " result = " + is_leap_year_result);

  } catch (Throwable _e) { _e.printStackTrace(); }

  try {
        long year = -1;

    boolean is_leap_year_result = _self.is_leap_year(year);
    System.out.println("Test 1 of is_leap_year on " + _self + " result = " + is_leap_year_result);

  } catch (Throwable _e) { _e.printStackTrace(); }

  try {
        long year = 1;

    boolean is_leap_year_result = _self.is_leap_year(year);
    System.out.println("Test 2 of is_leap_year on " + _self + " result = " + is_leap_year_result);

  } catch (Throwable _e) { _e.printStackTrace(); }

  try {
        long year = 9223372036854775807;

    boolean is_leap_year_result = _self.is_leap_year(year);
    System.out.println("Test 3 of is_leap_year on " + _self + " result = " + is_leap_year_result);

  } catch (Throwable _e) { _e.printStackTrace(); }

  try {
        long year = -9223372036854775808;

    boolean is_leap_year_result = _self.is_leap_year(year);
    System.out.println("Test 4 of is_leap_year on " + _self + " result = " + is_leap_year_result);

  } catch (Throwable _e) { _e.printStackTrace(); }


   for (int i = 0; i < _counts.length; i++)
   { if (_totals[i] > 0)
     { System.out.println("Test " + i + " detects " + (100.0*_counts[i])/_totals[i] + "% is_leap_year mutants"); }
     }
   }



  public static void calculate_days_between_dates_mutation_tests(FromPython _self, int[] _counts, int[] _totals)
  { 
   for (int i = 0; i < _counts.length; i++)
   { if (_totals[i] > 0)
     { System.out.println("Test " + i + " detects " + (100.0*_counts[i])/_totals[i] + "% calculate_days_between_dates mutants"); }
     }
   }



  public static void days360_mutation_tests(FromPython _self, int[] _counts, int[] _totals)
  { 
   for (int i = 0; i < _counts.length; i++)
   { if (_totals[i] > 0)
     { System.out.println("Test " + i + " detects " + (100.0*_counts[i])/_totals[i] + "% days360 mutants"); }
     }
   }



  public static void straddle_mutation_tests(FromPython _self, int[] _counts, int[] _totals)
  { 
   for (int i = 0; i < _counts.length; i++)
   { if (_totals[i] > 0)
     { System.out.println("Test " + i + " detects " + (100.0*_counts[i])/_totals[i] + "% straddle mutants"); }
     }
   }



  public static void acc_mutation_tests(FromPython _self, int[] _counts, int[] _totals)
  { 
   for (int i = 0; i < _counts.length; i++)
   { if (_totals[i] > 0)
     { System.out.println("Test " + i + " detects " + (100.0*_counts[i])/_totals[i] + "% acc mutants"); }
     }
   }



}
