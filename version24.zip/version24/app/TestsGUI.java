package app;


import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.Collection;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.HashSet;
import java.util.ArrayList;
import java.io.*;
import java.util.StringTokenizer;

public class TestsGUI extends JFrame implements ActionListener
{ JPanel panel = new JPanel();
  Controller cont = Controller.inst();
  JButton loadModelButton = new JButton("loadModel");
  JButton saveModelButton = new JButton("saveModel");
    JButton loadCSVButton = new JButton("Execute Tests");

 public TestsGUI()
  { super("Select use case to test");
    setContentPane(panel);
    addWindowListener(new WindowAdapter() 
    { public void windowClosing(WindowEvent e)
      { System.exit(0); } });
    panel.add(loadModelButton);
    loadModelButton.addActionListener(this);
    panel.add(saveModelButton);
    saveModelButton.addActionListener(this);
    panel.add(loadCSVButton);
    loadCSVButton.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e)
  { if (e == null) { return; }
    String cmd = e.getActionCommand();
    if ("loadModel".equals(cmd))
    { Controller.loadModel("in.txt");
      cont.checkCompleteness();
      System.err.println("Model loaded");
      return; } 
    if ("saveModel".equals(cmd))
    { cont.saveModel("out.txt");  
      return; } 
    if ("Execute Tests".equals(cmd))
    { System.err.println("Executing tests");
      int frompythons_instances = Controller.inst().frompythons.size();
      for (int _i = 0; _i < frompythons_instances; _i++)
      { FromPython _ex = (FromPython) Controller.inst().frompythons.get(_i);
        _ex.initialise();
      }
      System.out.println();
      int[] frompythons_comp_counts = new int[100]; 
      int[] frompythons_comp_totals = new int[100]; 
      for (int _i = 0; _i < frompythons_instances; _i++)
      { FromPython _ex = (FromPython) Controller.inst().frompythons.get(_i);
        MutationTest.comp_mutation_tests(_ex,frompythons_comp_counts, frompythons_comp_totals);
      }
      System.out.println();
      int[] frompythons_year_counts = new int[100]; 
      int[] frompythons_year_totals = new int[100]; 
      for (int _i = 0; _i < frompythons_instances; _i++)
      { FromPython _ex = (FromPython) Controller.inst().frompythons.get(_i);
        MutationTest.year_mutation_tests(_ex,frompythons_year_counts, frompythons_year_totals);
      }
      System.out.println();
      int[] frompythons_month_counts = new int[100]; 
      int[] frompythons_month_totals = new int[100]; 
      for (int _i = 0; _i < frompythons_instances; _i++)
      { FromPython _ex = (FromPython) Controller.inst().frompythons.get(_i);
        MutationTest.month_mutation_tests(_ex,frompythons_month_counts, frompythons_month_totals);
      }
      System.out.println();
      int[] frompythons_day_counts = new int[100]; 
      int[] frompythons_day_totals = new int[100]; 
      for (int _i = 0; _i < frompythons_instances; _i++)
      { FromPython _ex = (FromPython) Controller.inst().frompythons.get(_i);
        MutationTest.day_mutation_tests(_ex,frompythons_day_counts, frompythons_day_totals);
      }
      System.out.println();
      int[] frompythons_is_leap_year_counts = new int[100]; 
      int[] frompythons_is_leap_year_totals = new int[100]; 
      for (int _i = 0; _i < frompythons_instances; _i++)
      { FromPython _ex = (FromPython) Controller.inst().frompythons.get(_i);
        MutationTest.is_leap_year_mutation_tests(_ex,frompythons_is_leap_year_counts, frompythons_is_leap_year_totals);
      }
      System.out.println();
      int[] frompythons_calculate_days_between_dates_counts = new int[100]; 
      int[] frompythons_calculate_days_between_dates_totals = new int[100]; 
      for (int _i = 0; _i < frompythons_instances; _i++)
      { FromPython _ex = (FromPython) Controller.inst().frompythons.get(_i);
        MutationTest.calculate_days_between_dates_mutation_tests(_ex,frompythons_calculate_days_between_dates_counts, frompythons_calculate_days_between_dates_totals);
      }
      System.out.println();
      int[] frompythons_days360_counts = new int[100]; 
      int[] frompythons_days360_totals = new int[100]; 
      for (int _i = 0; _i < frompythons_instances; _i++)
      { FromPython _ex = (FromPython) Controller.inst().frompythons.get(_i);
        MutationTest.days360_mutation_tests(_ex,frompythons_days360_counts, frompythons_days360_totals);
      }
      System.out.println();
      int[] frompythons_straddle_counts = new int[100]; 
      int[] frompythons_straddle_totals = new int[100]; 
      for (int _i = 0; _i < frompythons_instances; _i++)
      { FromPython _ex = (FromPython) Controller.inst().frompythons.get(_i);
        MutationTest.straddle_mutation_tests(_ex,frompythons_straddle_counts, frompythons_straddle_totals);
      }
      System.out.println();
      int[] frompythons_acc_counts = new int[100]; 
      int[] frompythons_acc_totals = new int[100]; 
      for (int _i = 0; _i < frompythons_instances; _i++)
      { FromPython _ex = (FromPython) Controller.inst().frompythons.get(_i);
        MutationTest.acc_mutation_tests(_ex,frompythons_acc_counts, frompythons_acc_totals);
      }
      System.out.println();
      return;
    } 
    int[] intTestValues = {0, -1, 1, -1025, 1024};
    long[] longTestValues = {0, -1, 1, -999999, 100000};
    double[] doubleTestValues = {0, -1, 1, 3125.0891, 4.9E-324};
    boolean[] booleanTestValues = {false, true};
    String[] stringTestValues = {"", " abc_XZ ", "#�$* &~@'"};
    int MAXOBJECTS = 500;

  }

  public static void main(String[] args)
  { TestsGUI gui = new TestsGUI();
    gui.setSize(550,400);
    gui.setVisible(true);
  }
 }
